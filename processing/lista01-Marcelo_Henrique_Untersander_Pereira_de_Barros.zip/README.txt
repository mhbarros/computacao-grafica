Para executar, basta abrir o .html :)


Abrir o projeto no editor nativo do Processing pode quebrar algumas importações, pois fiz cada quadro em um arquivo separado. Abrir no VSCode ou Webstorm fica tudo bem :D